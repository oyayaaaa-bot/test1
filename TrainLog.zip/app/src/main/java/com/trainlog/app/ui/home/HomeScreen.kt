package com.trainlog.app.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.trainlog.app.data.entity.WorkoutSession
import com.trainlog.app.ui.navigation.Screen
import com.trainlog.app.util.GenericViewModelFactory
import com.trainlog.app.util.rememberAppContainer
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(navController: NavController) {
    val container = rememberAppContainer()
    val viewModel: HomeViewModel = viewModel(
        factory = GenericViewModelFactory {
            HomeViewModel(container.workoutPlanRepository, container.workoutSessionRepository)
        }
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    Scaffold(topBar = { TopAppBar(title = { Text("TrainLog") }) }) { padding ->
        if (uiState.isLoading) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                uiState.ongoingSession?.let { ongoing ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Тренировка в процессе", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))
                            Text(ongoing.planName ?: "Свободная тренировка")
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = {
                                navController.navigate(Screen.ActiveWorkout.createRoute(ongoing.id))
                            }) {
                                Text("Продолжить тренировку")
                            }
                        }
                    }
                }
            }

            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Сегодняшняя тренировка", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        if (uiState.suggestedPlan != null && uiState.suggestedDay != null) {
                            Text(uiState.suggestedPlan!!.name, style = MaterialTheme.typography.bodyLarge)
                            Text(uiState.suggestedDay!!.name, style = MaterialTheme.typography.bodyMedium)
                        } else if (uiState.hasAnyPlan) {
                            Text("В выбранной программе пока нет дней")
                        } else {
                            Text("У вас пока нет программы тренировок")
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                scope.launch {
                                    val plan = uiState.suggestedPlan
                                    val day = uiState.suggestedDay
                                    val sessionId = if (plan != null && day != null) {
                                        viewModel.startSessionForDay(plan, day)
                                    } else {
                                        viewModel.startFreeformSession()
                                    }
                                    navController.navigate(Screen.ActiveWorkout.createRoute(sessionId))
                                }
                            }) {
                                Text("Начать тренировку")
                            }
                            if (uiState.suggestedPlan != null && uiState.suggestedDay != null) {
                                OutlinedButton(onClick = {
                                    scope.launch {
                                        val sessionId = viewModel.startFreeformSession()
                                        navController.navigate(Screen.ActiveWorkout.createRoute(sessionId))
                                    }
                                }) {
                                    Text("Без программы")
                                }
                            }
                        }
                    }
                }
            }

            item {
                OutlinedButton(
                    onClick = { navController.navigate(Screen.Plans.route) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Создать программу")
                }
            }

            item {
                Text("Последние тренировки", style = MaterialTheme.typography.titleMedium)
            }

            if (uiState.recentSessions.isEmpty()) {
                item {
                    Text(
                        "Пока нет завершенных тренировок",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            } else {
                items(uiState.recentSessions, key = { it.id }) { session ->
                    RecentSessionRow(session) {
                        navController.navigate(Screen.SessionDetail.createRoute(session.id))
                    }
                }
            }
        }
    }
}

@Composable
private fun RecentSessionRow(session: WorkoutSession, onClick: () -> Unit) {
    val dateFormat = remember(session.id) { SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()) }
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(session.planName ?: "Свободная тренировка", style = MaterialTheme.typography.bodyLarge)
            session.dayName?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            Text(dateFormat.format(Date(session.startedAt)), style = MaterialTheme.typography.bodyMedium)
        }
    }
}
