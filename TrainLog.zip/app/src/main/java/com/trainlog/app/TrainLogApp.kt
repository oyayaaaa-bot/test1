package com.trainlog.app

import android.app.Application
import com.trainlog.app.di.AppContainer
import com.trainlog.app.util.NotificationHelper

class TrainLogApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        NotificationHelper.ensureChannel(this)
    }
}
