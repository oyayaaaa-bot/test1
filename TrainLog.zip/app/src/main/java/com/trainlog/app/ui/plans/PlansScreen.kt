package com.trainlog.app.ui.plans

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.trainlog.app.data.entity.WorkoutPlan
import com.trainlog.app.ui.components.ConfirmDialog
import com.trainlog.app.ui.navigation.Screen
import com.trainlog.app.util.GenericViewModelFactory
import com.trainlog.app.util.rememberAppContainer

@Composable
fun PlansScreen(navController: NavController) {
    val container = rememberAppContainer()
    val viewModel: PlansViewModel = viewModel(
        factory = GenericViewModelFactory { PlansViewModel(container.workoutPlanRepository) }
    )
    val plans by viewModel.plans.collectAsStateWithLifecycle()

    var showCreateDialog by remember { mutableStateOf(false) }
    var editingPlan by remember { mutableStateOf<WorkoutPlan?>(null) }
    var deletingPlan by remember { mutableStateOf<WorkoutPlan?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Программы тренировок") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreateDialog = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Создать программу")
            }
        }
    ) { padding ->
        if (plans.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp)
            ) {
                Text("У вас пока нет программ тренировок. Создайте первую с помощью кнопки ниже.")
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(plans, key = { it.id }) { plan ->
                    PlanRow(
                        plan = plan,
                        onClick = { navController.navigate(Screen.PlanDetail.createRoute(plan.id)) },
                        onEdit = { editingPlan = plan },
                        onDuplicate = { viewModel.duplicatePlan(plan) },
                        onDelete = { deletingPlan = plan }
                    )
                }
            }
        }
    }

    if (showCreateDialog) {
        PlanEditDialog(
            existing = null,
            onDismiss = { showCreateDialog = false },
            onSave = { name, description ->
                viewModel.createPlan(name, description) {}
                showCreateDialog = false
            }
        )
    }

    editingPlan?.let { plan ->
        PlanEditDialog(
            existing = plan,
            onDismiss = { editingPlan = null },
            onSave = { name, description ->
                viewModel.updatePlan(plan, name, description)
                editingPlan = null
            }
        )
    }

    deletingPlan?.let { plan ->
        ConfirmDialog(
            title = "Удалить программу?",
            message = "Программа «${plan.name}» и все ее дни будут удалены. История тренировок сохранится.",
            onConfirm = {
                viewModel.deletePlan(plan)
                deletingPlan = null
            },
            onDismiss = { deletingPlan = null }
        )
    }
}

@Composable
private fun PlanRow(
    plan: WorkoutPlan,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(vertical = 16.dp)) {
                Text(plan.name, style = MaterialTheme.typography.bodyLarge)
                if (plan.description.isNotBlank()) {
                    Text(
                        plan.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Filled.Edit, contentDescription = "Редактировать")
            }
            IconButton(onClick = onDuplicate) {
                Icon(Icons.Filled.ContentCopy, contentDescription = "Дублировать")
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Удалить")
            }
        }
    }
}
