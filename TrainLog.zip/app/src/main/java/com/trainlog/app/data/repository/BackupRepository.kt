package com.trainlog.app.data.repository

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.room.withTransaction
import com.trainlog.app.data.db.AppDatabase
import com.trainlog.app.data.entity.Exercise
import com.trainlog.app.data.entity.PlanExercise
import com.trainlog.app.data.entity.WorkoutDay
import com.trainlog.app.data.entity.WorkoutPlan
import com.trainlog.app.data.entity.WorkoutSession
import com.trainlog.app.data.entity.WorkoutSet
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val BACKUP_VERSION = 1

class BackupRepository(
    private val context: Context,
    private val database: AppDatabase
) {

    suspend fun exportHistoryCsv(): Uri {
        val sessions = database.workoutSessionDao().getAllFinishedSessionsWithSetsOnce()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val sb = StringBuilder()
        sb.append("Date,Plan,Day,Exercise,Set,Weight,Reps,Warmup,Completed,Note\n")
        sessions.forEach { sws ->
            val date = dateFormat.format(Date(sws.session.startedAt))
            val plan = csvEscape(sws.session.planName ?: "")
            val day = csvEscape(sws.session.dayName ?: "")
            sws.sets.sortedBy { it.set.setOrder }.forEach { setWithExercise ->
                sb.append(date).append(',')
                    .append(plan).append(',')
                    .append(day).append(',')
                    .append(csvEscape(setWithExercise.exercise.name)).append(',')
                    .append(setWithExercise.set.setOrder + 1).append(',')
                    .append(setWithExercise.set.weight).append(',')
                    .append(setWithExercise.set.reps).append(',')
                    .append(if (setWithExercise.set.isWarmup) "yes" else "no").append(',')
                    .append(if (setWithExercise.set.isCompleted) "yes" else "no").append(',')
                    .append(csvEscape(setWithExercise.set.note))
                    .append('\n')
            }
        }
        val fileName = "trainlog_history_${System.currentTimeMillis()}.csv"
        return writeExportFile(fileName, sb.toString())
    }

    suspend fun exportBackupJson(): Uri {
        val exercises = database.exerciseDao().getAllOnce()
        val plans = database.workoutPlanDao().getAllPlansOnce()
        val days = database.workoutPlanDao().getAllDaysOnce()
        val planExercises = database.workoutPlanDao().getAllPlanExercisesOnce()
        val sessions = database.workoutSessionDao().getAllSessionsOnce()
        val sets = database.workoutSessionDao().getAllSetsOnce()

        val root = JSONObject()
        root.put("version", BACKUP_VERSION)

        root.put("exercises", JSONArray().apply {
            exercises.forEach {
                put(JSONObject().apply {
                    put("id", it.id)
                    put("name", it.name)
                    put("muscleGroup", it.muscleGroup)
                    put("equipment", it.equipment)
                    put("description", it.description)
                    put("isCustom", it.isCustom)
                })
            }
        })

        root.put("plans", JSONArray().apply {
            plans.forEach {
                put(JSONObject().apply {
                    put("id", it.id)
                    put("name", it.name)
                    put("description", it.description)
                    put("createdAt", it.createdAt)
                })
            }
        })

        root.put("days", JSONArray().apply {
            days.forEach {
                put(JSONObject().apply {
                    put("id", it.id)
                    put("planId", it.planId)
                    put("name", it.name)
                    put("dayOrder", it.dayOrder)
                })
            }
        })

        root.put("planExercises", JSONArray().apply {
            planExercises.forEach {
                put(JSONObject().apply {
                    put("id", it.id)
                    put("workoutDayId", it.workoutDayId)
                    put("exerciseId", it.exerciseId)
                    put("exerciseOrder", it.exerciseOrder)
                    put("targetSets", it.targetSets)
                    put("targetReps", it.targetReps)
                    put("targetWeight", it.targetWeight)
                    put("restSeconds", it.restSeconds)
                    put("note", it.note)
                })
            }
        })

        root.put("sessions", JSONArray().apply {
            sessions.forEach {
                put(JSONObject().apply {
                    put("id", it.id)
                    put("planId", it.planId ?: JSONObject.NULL)
                    put("workoutDayId", it.workoutDayId ?: JSONObject.NULL)
                    put("planName", it.planName ?: JSONObject.NULL)
                    put("dayName", it.dayName ?: JSONObject.NULL)
                    put("startedAt", it.startedAt)
                    put("finishedAt", it.finishedAt ?: JSONObject.NULL)
                    put("note", it.note)
                })
            }
        })

        root.put("sets", JSONArray().apply {
            sets.forEach {
                put(JSONObject().apply {
                    put("id", it.id)
                    put("sessionId", it.sessionId)
                    put("exerciseId", it.exerciseId)
                    put("setOrder", it.setOrder)
                    put("weight", it.weight)
                    put("reps", it.reps)
                    put("isWarmup", it.isWarmup)
                    put("isCompleted", it.isCompleted)
                    put("note", it.note)
                })
            }
        })

        val fileName = "trainlog_backup_${System.currentTimeMillis()}.json"
        return writeExportFile(fileName, root.toString(2))
    }

    suspend fun importBackupJson(uri: Uri) {
        val text = context.contentResolver.openInputStream(uri)?.use { it.readBytes().decodeToString() }
            ?: throw IllegalArgumentException("Не удалось прочитать файл")
        val root = JSONObject(text)

        val exercises = root.getJSONArray("exercises").mapObjects {
            Exercise(
                id = it.getLong("id"),
                name = it.getString("name"),
                muscleGroup = it.getString("muscleGroup"),
                equipment = it.getString("equipment"),
                description = it.getString("description"),
                isCustom = it.getBoolean("isCustom")
            )
        }
        val plans = root.getJSONArray("plans").mapObjects {
            WorkoutPlan(
                id = it.getLong("id"),
                name = it.getString("name"),
                description = it.getString("description"),
                createdAt = it.getLong("createdAt")
            )
        }
        val days = root.getJSONArray("days").mapObjects {
            WorkoutDay(
                id = it.getLong("id"),
                planId = it.getLong("planId"),
                name = it.getString("name"),
                dayOrder = it.getInt("dayOrder")
            )
        }
        val planExercises = root.getJSONArray("planExercises").mapObjects {
            PlanExercise(
                id = it.getLong("id"),
                workoutDayId = it.getLong("workoutDayId"),
                exerciseId = it.getLong("exerciseId"),
                exerciseOrder = it.getInt("exerciseOrder"),
                targetSets = it.getInt("targetSets"),
                targetReps = it.getInt("targetReps"),
                targetWeight = it.getDouble("targetWeight"),
                restSeconds = it.getInt("restSeconds"),
                note = it.getString("note")
            )
        }
        val sessions = root.getJSONArray("sessions").mapObjects {
            WorkoutSession(
                id = it.getLong("id"),
                planId = it.optionalLong("planId"),
                workoutDayId = it.optionalLong("workoutDayId"),
                planName = it.optionalString("planName"),
                dayName = it.optionalString("dayName"),
                startedAt = it.getLong("startedAt"),
                finishedAt = it.optionalLong("finishedAt"),
                note = it.getString("note")
            )
        }
        val sets = root.getJSONArray("sets").mapObjects {
            WorkoutSet(
                id = it.getLong("id"),
                sessionId = it.getLong("sessionId"),
                exerciseId = it.getLong("exerciseId"),
                setOrder = it.getInt("setOrder"),
                weight = it.getDouble("weight"),
                reps = it.getInt("reps"),
                isWarmup = it.getBoolean("isWarmup"),
                isCompleted = it.getBoolean("isCompleted"),
                note = it.getString("note")
            )
        }

        database.withTransaction {
            database.clearAllTables()
            database.exerciseDao().insertAll(exercises)
            plans.forEach { database.workoutPlanDao().insertPlan(it) }
            days.forEach { database.workoutPlanDao().insertDay(it) }
            if (planExercises.isNotEmpty()) database.workoutPlanDao().insertPlanExercises(planExercises)
            sessions.forEach { database.workoutSessionDao().insertSession(it) }
            sets.forEach { database.workoutSessionDao().insertSet(it) }
        }
    }

    private fun writeExportFile(fileName: String, content: String): Uri {
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportDir, fileName)
        file.writeText(content)
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    private fun csvEscape(value: String): String {
        val escaped = value.replace("\"", "\"\"")
        return if (escaped.contains(',') || escaped.contains('\n') || escaped.contains('"')) {
            "\"$escaped\""
        } else {
            escaped
        }
    }

    private inline fun <T> JSONArray.mapObjects(transform: (JSONObject) -> T): List<T> =
        (0 until length()).map { transform(getJSONObject(it)) }

    private fun JSONObject.optionalLong(key: String): Long? =
        if (isNull(key)) null else getLong(key)

    private fun JSONObject.optionalString(key: String): String? =
        if (isNull(key)) null else getString(key)
}
