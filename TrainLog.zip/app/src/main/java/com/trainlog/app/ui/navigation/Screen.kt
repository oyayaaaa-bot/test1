package com.trainlog.app.ui.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Exercises : Screen("exercises")
    data object Plans : Screen("plans")
    data object History : Screen("history")
    data object Statistics : Screen("statistics")

    data object PlanDetail : Screen("plan/{planId}") {
        fun createRoute(planId: Long) = "plan/$planId"
    }

    data object WorkoutDayEditor : Screen("day/{dayId}") {
        fun createRoute(dayId: Long) = "day/$dayId"
    }

    data object ActiveWorkout : Screen("active/{sessionId}") {
        fun createRoute(sessionId: Long) = "active/$sessionId"
    }

    data object SessionDetail : Screen("session/{sessionId}") {
        fun createRoute(sessionId: Long) = "session/$sessionId"
    }
}

data class BottomNavItem(val screen: Screen, val label: String)

val bottomNavItems = listOf(
    BottomNavItem(Screen.Home, "Главная"),
    BottomNavItem(Screen.Plans, "Программы"),
    BottomNavItem(Screen.Exercises, "Упражнения"),
    BottomNavItem(Screen.History, "История"),
    BottomNavItem(Screen.Statistics, "Статистика")
)
