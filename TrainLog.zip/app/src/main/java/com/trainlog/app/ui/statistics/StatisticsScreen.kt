package com.trainlog.app.ui.statistics

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.trainlog.app.data.dao.ExerciseHistoryPoint
import com.trainlog.app.ui.components.ExercisePickerDialog
import com.trainlog.app.util.GenericViewModelFactory
import com.trainlog.app.util.rememberAppContainer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatisticsScreen() {
    val container = rememberAppContainer()
    val viewModel: StatisticsViewModel = viewModel(
        factory = GenericViewModelFactory {
            StatisticsViewModel(container.exerciseRepository, container.workoutSessionRepository)
        }
    )
    val allExercises by viewModel.allExercises.collectAsStateWithLifecycle()
    val selectedExerciseId by viewModel.selectedExerciseId.collectAsStateWithLifecycle()
    val stats by viewModel.stats.collectAsStateWithLifecycle()

    var showPicker by remember { mutableStateOf(false) }
    val selectedExercise = allExercises.find { it.id == selectedExerciseId }

    Scaffold(topBar = { TopAppBar(title = { Text("Статистика") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(selectedExercise?.name ?: "Выберите упражнение")
                }
            }

            if (selectedExercise == null) {
                item { Text("Выберите упражнение, чтобы увидеть статистику") }
            } else if (stats == null || stats!!.history.isEmpty()) {
                item { Text("Для этого упражнения пока нет завершенных подходов") }
            } else {
                val currentStats = stats!!
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        StatCard("Макс. вес", "${formatNumber(currentStats.maxWeight)} кг", Modifier.weight(1f))
                        StatCard("Макс. повторы", "${currentStats.maxReps}", Modifier.weight(1f))
                    }
                }
                item {
                    StatCard("Общий объем", "${formatNumber(currentStats.totalVolume)} кг", Modifier.fillMaxWidth())
                }
                item {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Прогресс веса по тренировкам", style = MaterialTheme.typography.titleMedium)
                            ProgressChart(
                                points = currentStats.history.filterNot { it.isWarmup },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp)
                                    .padding(top = 12.dp)
                            )
                        }
                    }
                }
                item {
                    Text("История подходов", style = MaterialTheme.typography.titleMedium)
                }
                items(currentStats.history) { point ->
                    HistoryPointRow(point)
                }
            }
        }
    }

    if (showPicker) {
        ExercisePickerDialog(
            exercises = allExercises,
            onDismiss = { showPicker = false },
            onPick = { exercise ->
                viewModel.selectExercise(exercise.id)
                showPicker = false
            }
        )
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
            Text(value, style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
private fun HistoryPointRow(point: ExerciseHistoryPoint) {
    val dateFormat = remember { SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()) }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(dateFormat.format(Date(point.startedAt)), style = MaterialTheme.typography.bodyMedium)
        Text(
            "${formatNumber(point.weight)} кг × ${point.reps}" + if (point.isWarmup) " (разминка)" else "",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
private fun ProgressChart(points: List<ExerciseHistoryPoint>, modifier: Modifier = Modifier) {
    if (points.size < 2) {
        Text("Недостаточно данных для графика", modifier = modifier)
        return
    }
    val lineColor = MaterialTheme.colorScheme.primary
    val values = points.map { it.weight }
    val maxValue = values.max()
    val minValue = values.min()
    val range = (maxValue - minValue).takeIf { it > 0.0 } ?: 1.0

    Canvas(modifier = modifier) {
        val stepX = size.width / (values.size - 1)
        val coordinates = values.mapIndexed { index, value ->
            val x = index * stepX
            val y = size.height - ((value - minValue) / range * size.height).toFloat()
            Offset(x, y)
        }
        for (i in 0 until coordinates.size - 1) {
            drawLine(
                color = lineColor,
                start = coordinates[i],
                end = coordinates[i + 1],
                strokeWidth = 4f
            )
        }
        coordinates.forEach { offset ->
            drawCircle(color = lineColor, radius = 6f, center = offset, style = Stroke(width = 3f))
        }
    }
}

private fun formatNumber(value: Double): String =
    if (value == value.toLong().toDouble()) value.toLong().toString() else "%.1f".format(value)
