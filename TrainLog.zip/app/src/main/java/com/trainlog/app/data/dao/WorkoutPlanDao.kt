package com.trainlog.app.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.trainlog.app.data.entity.PlanExercise
import com.trainlog.app.data.entity.WorkoutDay
import com.trainlog.app.data.entity.WorkoutPlan
import com.trainlog.app.data.relation.DayWithExercises
import com.trainlog.app.data.relation.PlanExerciseWithExercise
import com.trainlog.app.data.relation.PlanWithDays
import com.trainlog.app.data.relation.PlanWithDaysAndExercises
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkoutPlanDao {

    @Query("SELECT * FROM workout_plans ORDER BY createdAt DESC")
    fun observePlans(): Flow<List<WorkoutPlan>>

    @Query("SELECT * FROM workout_plans WHERE id = :id")
    suspend fun getPlan(id: Long): WorkoutPlan?

    @Transaction
    @Query("SELECT * FROM workout_plans WHERE id = :id")
    fun observePlanWithDays(id: Long): Flow<PlanWithDays?>

    @Transaction
    @Query("SELECT * FROM workout_plans WHERE id = :id")
    fun observePlanWithDaysAndExercises(id: Long): Flow<PlanWithDaysAndExercises?>

    @Transaction
    @Query("SELECT * FROM workout_plans WHERE id = :id")
    suspend fun getPlanWithDaysAndExercisesOnce(id: Long): PlanWithDaysAndExercises?

    @Insert
    suspend fun insertPlan(plan: WorkoutPlan): Long

    @Update
    suspend fun updatePlan(plan: WorkoutPlan)

    @Delete
    suspend fun deletePlan(plan: WorkoutPlan)

    @Query("SELECT * FROM workout_days WHERE planId = :planId ORDER BY dayOrder ASC")
    fun observeDaysForPlan(planId: Long): Flow<List<WorkoutDay>>

    @Query("SELECT * FROM workout_days WHERE id = :id")
    suspend fun getDay(id: Long): WorkoutDay?

    @Transaction
    @Query("SELECT * FROM workout_days WHERE id = :id")
    fun observeDayWithExercises(id: Long): Flow<DayWithExercises?>

    @Query("SELECT COALESCE(MAX(dayOrder), -1) FROM workout_days WHERE planId = :planId")
    suspend fun getMaxDayOrder(planId: Long): Int

    @Insert
    suspend fun insertDay(day: WorkoutDay): Long

    @Insert
    suspend fun insertDays(days: List<WorkoutDay>)

    @Update
    suspend fun updateDay(day: WorkoutDay)

    @Update
    suspend fun updateDays(days: List<WorkoutDay>)

    @Delete
    suspend fun deleteDay(day: WorkoutDay)

    @Query("SELECT COALESCE(MAX(exerciseOrder), -1) FROM plan_exercises WHERE workoutDayId = :dayId")
    suspend fun getMaxExerciseOrder(dayId: Long): Int

    @Insert
    suspend fun insertPlanExercise(planExercise: PlanExercise): Long

    @Insert
    suspend fun insertPlanExercises(planExercises: List<PlanExercise>)

    @Update
    suspend fun updatePlanExercise(planExercise: PlanExercise)

    @Update
    suspend fun updatePlanExercises(planExercises: List<PlanExercise>)

    @Delete
    suspend fun deletePlanExercise(planExercise: PlanExercise)

    @Query("SELECT * FROM plan_exercises WHERE workoutDayId = :dayId ORDER BY exerciseOrder ASC")
    suspend fun getPlanExercisesForDay(dayId: Long): List<PlanExercise>

    @Transaction
    @Query("SELECT * FROM plan_exercises WHERE workoutDayId = :dayId ORDER BY exerciseOrder ASC")
    suspend fun getPlanExercisesWithExerciseForDay(dayId: Long): List<PlanExerciseWithExercise>

    @Query("SELECT * FROM workout_plans ORDER BY id ASC")
    suspend fun getAllPlansOnce(): List<WorkoutPlan>

    @Query("SELECT * FROM workout_days ORDER BY id ASC")
    suspend fun getAllDaysOnce(): List<WorkoutDay>

    @Query("SELECT * FROM plan_exercises ORDER BY id ASC")
    suspend fun getAllPlanExercisesOnce(): List<PlanExercise>
}
