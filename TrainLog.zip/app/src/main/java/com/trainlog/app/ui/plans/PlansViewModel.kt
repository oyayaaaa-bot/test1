package com.trainlog.app.ui.plans

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.trainlog.app.data.entity.WorkoutPlan
import com.trainlog.app.data.repository.WorkoutPlanRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PlansViewModel(private val repository: WorkoutPlanRepository) : ViewModel() {

    val plans: StateFlow<List<WorkoutPlan>> = repository.observePlans()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun createPlan(name: String, description: String, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val id = repository.createPlan(name, description)
            onCreated(id)
        }
    }

    fun updatePlan(plan: WorkoutPlan, name: String, description: String) {
        viewModelScope.launch {
            repository.updatePlan(plan.copy(name = name.trim(), description = description.trim()))
        }
    }

    fun deletePlan(plan: WorkoutPlan) {
        viewModelScope.launch { repository.deletePlan(plan) }
    }

    fun duplicatePlan(plan: WorkoutPlan) {
        viewModelScope.launch { repository.duplicatePlan(plan.id) }
    }
}
