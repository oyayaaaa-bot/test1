package com.trainlog.app.ui.plans

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.trainlog.app.data.entity.WorkoutDay
import com.trainlog.app.ui.components.ConfirmDialog
import com.trainlog.app.ui.navigation.Screen
import com.trainlog.app.util.GenericViewModelFactory
import com.trainlog.app.util.rememberAppContainer
import kotlinx.coroutines.launch

@Composable
fun PlanDetailScreen(navController: NavController, planId: Long) {
    val container = rememberAppContainer()
    val viewModel: PlanDetailViewModel = viewModel(
        factory = GenericViewModelFactory {
            PlanDetailViewModel(planId, container.workoutPlanRepository, container.workoutSessionRepository)
        }
    )
    val planWithDays by viewModel.planWithDays.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var showAddDayDialog by remember { mutableStateOf(false) }
    var renamingDay by remember { mutableStateOf<WorkoutDay?>(null) }
    var deletingDay by remember { mutableStateOf<WorkoutDay?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(planWithDays?.plan?.name ?: "Программа") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDayDialog = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Добавить день")
            }
        }
    ) { padding ->
        val plan = planWithDays
        if (plan == null) {
            Column(modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp)) {
                Text("Загрузка...")
            }
            return@Scaffold
        }

        val days = plan.days.sortedBy { it.dayOrder }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (plan.plan.description.isNotBlank()) {
                item {
                    Text(plan.plan.description, style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (days.isEmpty()) {
                item { Text("В программе пока нет тренировочных дней. Добавьте первый.") }
            }
            items(days, key = { it.id }) { day ->
                DayRow(
                    day = day,
                    canMoveUp = days.indexOf(day) > 0,
                    canMoveDown = days.indexOf(day) < days.size - 1,
                    onClick = { navController.navigate(Screen.WorkoutDayEditor.createRoute(day.id)) },
                    onStart = {
                        scope.launch {
                            val sessionId = viewModel.startSessionForDay(plan.plan.name, day)
                            navController.navigate(Screen.ActiveWorkout.createRoute(sessionId))
                        }
                    },
                    onRename = { renamingDay = day },
                    onDelete = { deletingDay = day },
                    onMoveUp = { viewModel.moveDay(day, days, -1) },
                    onMoveDown = { viewModel.moveDay(day, days, 1) }
                )
            }
        }
    }

    if (showAddDayDialog) {
        DayNameDialog(
            initialName = "",
            title = "Новый день",
            onDismiss = { showAddDayDialog = false },
            onSave = { name ->
                viewModel.addDay(name)
                showAddDayDialog = false
            }
        )
    }

    renamingDay?.let { day ->
        DayNameDialog(
            initialName = day.name,
            title = "Переименовать день",
            onDismiss = { renamingDay = null },
            onSave = { name ->
                viewModel.renameDay(day, name)
                renamingDay = null
            }
        )
    }

    deletingDay?.let { day ->
        ConfirmDialog(
            title = "Удалить день?",
            message = "День «${day.name}» и его упражнения будут удалены из программы.",
            onConfirm = {
                viewModel.deleteDay(day)
                deletingDay = null
            },
            onDismiss = { deletingDay = null }
        )
    }
}

@Composable
private fun DayRow(
    day: WorkoutDay,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onClick: () -> Unit,
    onStart: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(day.name, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                IconButton(onClick = onMoveUp, enabled = canMoveUp) {
                    Icon(Icons.Filled.ArrowUpward, contentDescription = "Переместить вверх")
                }
                IconButton(onClick = onMoveDown, enabled = canMoveDown) {
                    Icon(Icons.Filled.ArrowDownward, contentDescription = "Переместить вниз")
                }
                IconButton(onClick = onRename) {
                    Icon(Icons.Filled.Edit, contentDescription = "Переименовать")
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Удалить")
                }
            }
            Button(onClick = onStart, modifier = Modifier.padding(top = 4.dp)) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                Text("Начать")
            }
        }
    }
}

@Composable
private fun DayNameDialog(
    initialName: String,
    title: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Название дня") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(name) }) { Text("Сохранить") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}
