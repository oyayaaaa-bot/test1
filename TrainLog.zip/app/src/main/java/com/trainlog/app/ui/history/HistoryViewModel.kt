package com.trainlog.app.ui.history

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.trainlog.app.data.entity.WorkoutSession
import com.trainlog.app.data.repository.BackupRepository
import com.trainlog.app.data.repository.WorkoutSessionRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HistoryViewModel(
    private val sessionRepository: WorkoutSessionRepository,
    private val backupRepository: BackupRepository
) : ViewModel() {

    val sessions: StateFlow<List<WorkoutSession>> = sessionRepository.observeAllFinishedSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun deleteSession(session: WorkoutSession) {
        viewModelScope.launch { sessionRepository.deleteSession(session) }
    }

    suspend fun exportCsv(): Uri = backupRepository.exportHistoryCsv()

    suspend fun exportBackup(): Uri = backupRepository.exportBackupJson()

    suspend fun importBackup(uri: Uri) {
        backupRepository.importBackupJson(uri)
    }
}
