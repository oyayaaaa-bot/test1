package com.trainlog.app.di

import android.content.Context
import com.trainlog.app.data.db.AppDatabase
import com.trainlog.app.data.repository.BackupRepository
import com.trainlog.app.data.repository.ExerciseRepository
import com.trainlog.app.data.repository.WorkoutPlanRepository
import com.trainlog.app.data.repository.WorkoutSessionRepository

class AppContainer(context: Context) {
    private val database = AppDatabase.getInstance(context)

    val exerciseRepository = ExerciseRepository(database.exerciseDao())
    val workoutPlanRepository = WorkoutPlanRepository(database.workoutPlanDao())
    val workoutSessionRepository = WorkoutSessionRepository(database.workoutSessionDao())
    val backupRepository = BackupRepository(context.applicationContext, database)
}
