package com.trainlog.app.ui.history

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.trainlog.app.data.entity.WorkoutSession
import com.trainlog.app.ui.components.ConfirmDialog
import com.trainlog.app.ui.navigation.Screen
import com.trainlog.app.util.GenericViewModelFactory
import com.trainlog.app.util.rememberAppContainer
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(navController: NavController) {
    val context = LocalContext.current
    val container = rememberAppContainer()
    val viewModel: HistoryViewModel = viewModel(
        factory = GenericViewModelFactory {
            HistoryViewModel(container.workoutSessionRepository, container.backupRepository)
        }
    )
    val sessions by viewModel.sessions.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var deletingSession by remember { mutableStateOf<WorkoutSession?>(null) }
    var showMenu by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                runCatching { viewModel.importBackup(uri) }
                    .onSuccess { snackbarHostState.showSnackbar("Резервная копия импортирована") }
                    .onFailure { snackbarHostState.showSnackbar("Не удалось импортировать: ${it.message}") }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("История тренировок") },
                actions = {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "Меню")
                    }
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("Экспорт истории в CSV") },
                            onClick = {
                                showMenu = false
                                scope.launch {
                                    val uri = viewModel.exportCsv()
                                    shareFile(context, uri, "text/csv")
                                }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Экспорт резервной копии (JSON)") },
                            onClick = {
                                showMenu = false
                                scope.launch {
                                    val uri = viewModel.exportBackup()
                                    shareFile(context, uri, "application/json")
                                }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Импорт резервной копии") },
                            onClick = {
                                showMenu = false
                                importLauncher.launch("application/json")
                            }
                        )
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        if (sessions.isEmpty()) {
            Column(modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp)) {
                Text("Здесь появится история завершенных тренировок")
            }
        } else {
            val dateHeaderFormat = remember { SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()) }
            val grouped = sessions.groupBy { dateHeaderFormat.format(Date(it.startedAt)) }

            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                grouped.forEach { (date, sessionsForDate) ->
                    item {
                        Text(
                            date,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                    items(sessionsForDate, key = { it.id }) { session ->
                        SessionRow(
                            session = session,
                            onClick = { navController.navigate(Screen.SessionDetail.createRoute(session.id)) },
                            onDelete = { deletingSession = session }
                        )
                    }
                }
            }
        }
    }

    deletingSession?.let { session ->
        ConfirmDialog(
            title = "Удалить тренировку?",
            message = "Тренировка и все ее подходы будут удалены безвозвратно.",
            onConfirm = {
                viewModel.deleteSession(session)
                deletingSession = null
            },
            onDismiss = { deletingSession = null }
        )
    }
}

private fun shareFile(context: android.content.Context, uri: Uri, mimeType: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Поделиться файлом"))
}

@Composable
private fun SessionRow(session: WorkoutSession, onClick: () -> Unit, onDelete: () -> Unit) {
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    Card(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Column {
                Text(session.planName ?: "Свободная тренировка", style = MaterialTheme.typography.bodyLarge)
                session.dayName?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                Text(timeFormat.format(Date(session.startedAt)), style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Удалить")
            }
        }
    }
}
