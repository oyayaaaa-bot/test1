package com.trainlog.app.ui.plans

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.trainlog.app.data.entity.WorkoutDay
import com.trainlog.app.data.relation.PlanWithDays
import com.trainlog.app.data.repository.WorkoutPlanRepository
import com.trainlog.app.data.repository.WorkoutSessionRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PlanDetailViewModel(
    private val planId: Long,
    private val planRepository: WorkoutPlanRepository,
    private val sessionRepository: WorkoutSessionRepository
) : ViewModel() {

    val planWithDays: StateFlow<PlanWithDays?> = planRepository.observePlanWithDays(planId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun addDay(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch { planRepository.addDay(planId, name) }
    }

    fun renameDay(day: WorkoutDay, newName: String) {
        if (newName.isBlank()) return
        viewModelScope.launch { planRepository.updateDay(day.copy(name = newName.trim())) }
    }

    fun deleteDay(day: WorkoutDay) {
        viewModelScope.launch { planRepository.deleteDay(day) }
    }

    fun moveDay(day: WorkoutDay, days: List<WorkoutDay>, delta: Int) {
        val sorted = days.sortedBy { it.dayOrder }
        val index = sorted.indexOf(day)
        val newIndex = index + delta
        if (newIndex < 0 || newIndex >= sorted.size) return
        val mutable = sorted.toMutableList()
        val moved = mutable.removeAt(index)
        mutable.add(newIndex, moved)
        viewModelScope.launch { planRepository.reorderDays(mutable) }
    }

    suspend fun startSessionForDay(planName: String, day: WorkoutDay): Long =
        sessionRepository.startSession(
            planId = planId,
            workoutDayId = day.id,
            planName = planName,
            dayName = day.name
        )
}
