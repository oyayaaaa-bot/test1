package com.trainlog.app.ui.exercises

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.trainlog.app.data.entity.Exercise
import com.trainlog.app.data.entity.MuscleGroup
import com.trainlog.app.ui.components.ConfirmDialog
import com.trainlog.app.util.GenericViewModelFactory
import com.trainlog.app.util.rememberAppContainer

@Composable
fun ExercisesScreen() {
    val container = rememberAppContainer()
    val viewModel: ExercisesViewModel = viewModel(
        factory = GenericViewModelFactory { ExercisesViewModel(container.exerciseRepository) }
    )

    val query by viewModel.query.collectAsStateWithLifecycle()
    val selectedGroup by viewModel.selectedMuscleGroup.collectAsStateWithLifecycle()
    val exercises by viewModel.exercises.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()

    var showAddDialog by remember { mutableStateOf(false) }
    var editingExercise by remember { mutableStateOf<Exercise?>(null) }
    var deletingExercise by remember { mutableStateOf<Exercise?>(null) }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Упражнения") }) },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Добавить упражнение")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = viewModel::onQueryChange,
                label = { Text("Поиск по названию") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )

            LazyRow(
                modifier = Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedGroup == null,
                        onClick = { viewModel.onMuscleGroupSelected(null) },
                        label = { Text("Все") }
                    )
                }
                items(MuscleGroup.entries) { group ->
                    FilterChip(
                        selected = selectedGroup == group,
                        onClick = { viewModel.onMuscleGroupSelected(group) },
                        label = { Text(group.label) }
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(exercises, key = { it.id }) { exercise ->
                    ExerciseRow(
                        exercise = exercise,
                        onEdit = { editingExercise = exercise },
                        onDelete = { deletingExercise = exercise }
                    )
                }
            }
        }
    }

    if (showAddDialog) {
        ExerciseEditDialog(
            existing = null,
            onDismiss = { showAddDialog = false },
            onSave = { name, muscleGroup, equipment, description ->
                viewModel.addExercise(name, muscleGroup, equipment, description)
                showAddDialog = false
            }
        )
    }

    editingExercise?.let { exercise ->
        ExerciseEditDialog(
            existing = exercise,
            onDismiss = { editingExercise = null },
            onSave = { name, muscleGroup, equipment, description ->
                viewModel.updateExercise(exercise, name, muscleGroup, equipment, description)
                editingExercise = null
            }
        )
    }

    deletingExercise?.let { exercise ->
        ConfirmDialog(
            title = "Удалить упражнение?",
            message = "Упражнение «${exercise.name}» будет удалено безвозвратно.",
            onConfirm = {
                viewModel.deleteExercise(exercise)
                deletingExercise = null
            },
            onDismiss = { deletingExercise = null }
        )
    }
}

@Composable
private fun ExerciseRow(exercise: Exercise, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(exercise.name, style = MaterialTheme.typography.bodyLarge)
                Text(
                    "${exercise.muscleGroup} • ${exercise.equipment}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
            if (exercise.isCustom) {
                IconButton(onClick = onEdit) {
                    Icon(Icons.Filled.Edit, contentDescription = "Редактировать")
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Удалить")
                }
            }
        }
    }
}
