package com.trainlog.app.ui.plans

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.trainlog.app.data.entity.Exercise
import com.trainlog.app.data.entity.PlanExercise
import com.trainlog.app.data.relation.DayWithExercises
import com.trainlog.app.data.relation.PlanExerciseWithExercise
import com.trainlog.app.data.repository.ExerciseRepository
import com.trainlog.app.data.repository.WorkoutPlanRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class WorkoutDayViewModel(
    private val dayId: Long,
    private val planRepository: WorkoutPlanRepository,
    exerciseRepository: ExerciseRepository
) : ViewModel() {

    val dayWithExercises: StateFlow<DayWithExercises?> = planRepository.observeDayWithExercises(dayId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allExercises: StateFlow<List<Exercise>> = exerciseRepository.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addExercise(
        exerciseId: Long,
        targetSets: Int,
        targetReps: Int,
        targetWeight: Double,
        restSeconds: Int,
        note: String
    ) {
        viewModelScope.launch {
            planRepository.addExerciseToDay(dayId, exerciseId, targetSets, targetReps, targetWeight, restSeconds, note)
        }
    }

    fun updateExercise(planExercise: PlanExercise) {
        viewModelScope.launch { planRepository.updatePlanExercise(planExercise) }
    }

    fun deleteExercise(planExercise: PlanExercise) {
        viewModelScope.launch { planRepository.deletePlanExercise(planExercise) }
    }

    fun moveExercise(item: PlanExerciseWithExercise, items: List<PlanExerciseWithExercise>, delta: Int) {
        val sorted = items.sortedBy { it.planExercise.exerciseOrder }
        val index = sorted.indexOf(item)
        val newIndex = index + delta
        if (newIndex < 0 || newIndex >= sorted.size) return
        val mutable = sorted.toMutableList()
        val moved = mutable.removeAt(index)
        mutable.add(newIndex, moved)
        viewModelScope.launch {
            planRepository.reorderExercises(mutable.map { it.planExercise })
        }
    }
}
