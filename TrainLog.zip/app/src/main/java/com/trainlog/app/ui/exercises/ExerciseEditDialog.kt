package com.trainlog.app.ui.exercises

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.trainlog.app.data.entity.Exercise
import com.trainlog.app.data.entity.MuscleGroup

@Composable
fun ExerciseEditDialog(
    existing: Exercise?,
    onDismiss: () -> Unit,
    onSave: (name: String, muscleGroup: MuscleGroup, equipment: String, description: String) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name.orEmpty()) }
    var equipment by remember { mutableStateOf(existing?.equipment.orEmpty()) }
    var description by remember { mutableStateOf(existing?.description.orEmpty()) }
    var muscleGroup by remember {
        mutableStateOf(existing?.let { MuscleGroup.fromLabel(it.muscleGroup) } ?: MuscleGroup.OTHER)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Новое упражнение" else "Редактировать упражнение") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Группа мышц", modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
                LazyRow {
                    items(MuscleGroup.entries) { group ->
                        FilterChip(
                            selected = muscleGroup == group,
                            onClick = { muscleGroup = group },
                            label = { Text(group.label) },
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                }
                OutlinedTextField(
                    value = equipment,
                    onValueChange = { equipment = it },
                    label = { Text("Инвентарь") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Описание") },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name, muscleGroup, equipment, description) }) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}
