package com.trainlog.app.data.repository

import com.trainlog.app.data.dao.WorkoutPlanDao
import com.trainlog.app.data.entity.PlanExercise
import com.trainlog.app.data.entity.WorkoutDay
import com.trainlog.app.data.entity.WorkoutPlan
import com.trainlog.app.data.relation.DayWithExercises
import com.trainlog.app.data.relation.PlanWithDays
import com.trainlog.app.data.relation.PlanWithDaysAndExercises
import kotlinx.coroutines.flow.Flow

class WorkoutPlanRepository(private val planDao: WorkoutPlanDao) {

    fun observePlans(): Flow<List<WorkoutPlan>> = planDao.observePlans()

    fun observePlanWithDays(planId: Long): Flow<PlanWithDays?> = planDao.observePlanWithDays(planId)

    fun observePlanWithDaysAndExercises(planId: Long): Flow<PlanWithDaysAndExercises?> =
        planDao.observePlanWithDaysAndExercises(planId)

    fun observeDayWithExercises(dayId: Long): Flow<DayWithExercises?> =
        planDao.observeDayWithExercises(dayId)

    suspend fun getPlan(planId: Long): WorkoutPlan? = planDao.getPlan(planId)

    suspend fun getDay(dayId: Long): WorkoutDay? = planDao.getDay(dayId)

    suspend fun createPlan(name: String, description: String): Long =
        planDao.insertPlan(
            WorkoutPlan(name = name.trim(), description = description.trim(), createdAt = System.currentTimeMillis())
        )

    suspend fun updatePlan(plan: WorkoutPlan) = planDao.updatePlan(plan)

    suspend fun deletePlan(plan: WorkoutPlan) = planDao.deletePlan(plan)

    suspend fun duplicatePlan(planId: Long): Long? {
        val original = planDao.getPlanWithDaysAndExercisesOnce(planId) ?: return null
        val newPlanId = planDao.insertPlan(
            original.plan.copy(id = 0, name = "${original.plan.name} (копия)", createdAt = System.currentTimeMillis())
        )
        original.days.sortedBy { it.day.dayOrder }.forEach { dayWithExercises ->
            val newDayId = planDao.insertDay(dayWithExercises.day.copy(id = 0, planId = newPlanId))
            val newExercises = dayWithExercises.exercises.map {
                it.planExercise.copy(id = 0, workoutDayId = newDayId)
            }
            if (newExercises.isNotEmpty()) planDao.insertPlanExercises(newExercises)
        }
        return newPlanId
    }

    fun observeDaysForPlan(planId: Long): Flow<List<WorkoutDay>> = planDao.observeDaysForPlan(planId)

    suspend fun addDay(planId: Long, name: String): Long {
        val order = planDao.getMaxDayOrder(planId) + 1
        return planDao.insertDay(WorkoutDay(planId = planId, name = name.trim(), dayOrder = order))
    }

    suspend fun updateDay(day: WorkoutDay) = planDao.updateDay(day)

    suspend fun deleteDay(day: WorkoutDay) = planDao.deleteDay(day)

    suspend fun reorderDays(days: List<WorkoutDay>) {
        planDao.updateDays(days.mapIndexed { index, day -> day.copy(dayOrder = index) })
    }

    suspend fun addExerciseToDay(
        dayId: Long,
        exerciseId: Long,
        targetSets: Int,
        targetReps: Int,
        targetWeight: Double,
        restSeconds: Int,
        note: String
    ): Long {
        val order = planDao.getMaxExerciseOrder(dayId) + 1
        return planDao.insertPlanExercise(
            PlanExercise(
                workoutDayId = dayId,
                exerciseId = exerciseId,
                exerciseOrder = order,
                targetSets = targetSets,
                targetReps = targetReps,
                targetWeight = targetWeight,
                restSeconds = restSeconds,
                note = note.trim()
            )
        )
    }

    suspend fun updatePlanExercise(planExercise: PlanExercise) = planDao.updatePlanExercise(planExercise)

    suspend fun deletePlanExercise(planExercise: PlanExercise) = planDao.deletePlanExercise(planExercise)

    suspend fun reorderExercises(exercises: List<PlanExercise>) {
        planDao.updatePlanExercises(exercises.mapIndexed { index, ex -> ex.copy(exerciseOrder = index) })
    }
}
