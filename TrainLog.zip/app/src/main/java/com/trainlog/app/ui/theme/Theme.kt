package com.trainlog.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = TrainPrimaryLight,
    onPrimary = TrainOnPrimaryLight,
    primaryContainer = TrainPrimaryContainerLight,
    secondary = TrainSecondaryLight,
    background = TrainBackgroundLight,
    surface = TrainSurfaceLight,
    error = TrainErrorLight
)

private val DarkColors = darkColorScheme(
    primary = TrainPrimaryDark,
    onPrimary = TrainOnPrimaryDark,
    primaryContainer = TrainPrimaryContainerDark,
    secondary = TrainSecondaryDark,
    background = TrainBackgroundDark,
    surface = TrainSurfaceDark,
    error = TrainErrorDark
)

@Composable
fun TrainLogTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = TrainLogTypography,
        content = content
    )
}
