package com.trainlog.app.data.entity

enum class MuscleGroup(val label: String) {
    CHEST("Грудь"),
    BACK("Спина"),
    LEGS("Ноги"),
    SHOULDERS("Плечи"),
    ARMS("Руки"),
    CORE("Пресс"),
    CARDIO("Кардио"),
    FULL_BODY("Все тело"),
    OTHER("Другое");

    companion object {
        fun fromLabel(label: String): MuscleGroup = entries.firstOrNull { it.label == label } ?: OTHER
    }
}
