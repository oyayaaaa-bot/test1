package com.trainlog.app.ui.theme

import androidx.compose.ui.graphics.Color

val TrainPrimaryLight = Color(0xFF17694B)
val TrainOnPrimaryLight = Color(0xFFFFFFFF)
val TrainPrimaryContainerLight = Color(0xFFA6F2CE)
val TrainSecondaryLight = Color(0xFF4C6358)
val TrainBackgroundLight = Color(0xFFF7FBF6)
val TrainSurfaceLight = Color(0xFFF7FBF6)
val TrainErrorLight = Color(0xFFBA1A1A)

val TrainPrimaryDark = Color(0xFF89D6B2)
val TrainOnPrimaryDark = Color(0xFF003824)
val TrainPrimaryContainerDark = Color(0xFF00513A)
val TrainSecondaryDark = Color(0xFFB3CCBF)
val TrainBackgroundDark = Color(0xFF101512)
val TrainSurfaceDark = Color(0xFF101512)
val TrainErrorDark = Color(0xFFFFB4AB)
