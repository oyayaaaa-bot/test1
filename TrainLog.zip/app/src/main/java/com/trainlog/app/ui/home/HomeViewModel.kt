package com.trainlog.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.trainlog.app.data.entity.WorkoutDay
import com.trainlog.app.data.entity.WorkoutPlan
import com.trainlog.app.data.entity.WorkoutSession
import com.trainlog.app.data.repository.WorkoutPlanRepository
import com.trainlog.app.data.repository.WorkoutSessionRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class HomeUiState(
    val isLoading: Boolean = true,
    val ongoingSession: WorkoutSession? = null,
    val suggestedPlan: WorkoutPlan? = null,
    val suggestedDay: WorkoutDay? = null,
    val recentSessions: List<WorkoutSession> = emptyList(),
    val hasAnyPlan: Boolean = false
)

class HomeViewModel(
    private val planRepository: WorkoutPlanRepository,
    private val sessionRepository: WorkoutSessionRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                planRepository.observePlans(),
                sessionRepository.observeRecentSessions(3),
                sessionRepository.observeOngoingSession()
            ) { plans, recentSessions, ongoing ->
                Triple(plans, recentSessions, ongoing)
            }.collect { (plans, recentSessions, ongoing) ->
                val (plan, day) = computeSuggestion(plans, recentSessions)
                _uiState.value = HomeUiState(
                    isLoading = false,
                    ongoingSession = ongoing,
                    suggestedPlan = plan,
                    suggestedDay = day,
                    recentSessions = recentSessions,
                    hasAnyPlan = plans.isNotEmpty()
                )
            }
        }
    }

    private suspend fun computeSuggestion(
        plans: List<WorkoutPlan>,
        recentSessions: List<WorkoutSession>
    ): Pair<WorkoutPlan?, WorkoutDay?> {
        if (plans.isEmpty()) return null to null

        val lastPlanSession = recentSessions.firstOrNull { it.planId != null }
        val targetPlan = lastPlanSession?.planId?.let { planId -> plans.find { it.id == planId } }
            ?: plans.first()

        val days = planRepository.observeDaysForPlan(targetPlan.id).first()
        if (days.isEmpty()) return targetPlan to null

        val lastDayId = lastPlanSession?.workoutDayId
        val lastDay = days.find { it.id == lastDayId }
        val nextDay = if (lastDay != null) {
            val sorted = days.sortedBy { it.dayOrder }
            val idx = sorted.indexOf(lastDay)
            sorted[(idx + 1) % sorted.size]
        } else {
            days.minByOrNull { it.dayOrder }
        }
        return targetPlan to nextDay
    }

    suspend fun startFreeformSession(): Long =
        sessionRepository.startSession(planId = null, workoutDayId = null, planName = null, dayName = null)

    suspend fun startSessionForDay(plan: WorkoutPlan, day: WorkoutDay): Long =
        sessionRepository.startSession(
            planId = plan.id,
            workoutDayId = day.id,
            planName = plan.name,
            dayName = day.name
        )
}
