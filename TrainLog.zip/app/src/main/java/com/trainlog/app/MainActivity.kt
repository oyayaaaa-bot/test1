package com.trainlog.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.trainlog.app.ui.navigation.TrainLogNavGraph
import com.trainlog.app.ui.theme.TrainLogTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TrainLogTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    TrainLogNavGraph()
                }
            }
        }
    }
}
