package com.trainlog.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.trainlog.app.data.dao.ExerciseDao
import com.trainlog.app.data.dao.WorkoutPlanDao
import com.trainlog.app.data.dao.WorkoutSessionDao
import com.trainlog.app.data.entity.Exercise
import com.trainlog.app.data.entity.PlanExercise
import com.trainlog.app.data.entity.WorkoutDay
import com.trainlog.app.data.entity.WorkoutPlan
import com.trainlog.app.data.entity.WorkoutSession
import com.trainlog.app.data.entity.WorkoutSet
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@Database(
    entities = [
        Exercise::class,
        WorkoutPlan::class,
        WorkoutDay::class,
        PlanExercise::class,
        WorkoutSession::class,
        WorkoutSet::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun exerciseDao(): ExerciseDao
    abstract fun workoutPlanDao(): WorkoutPlanDao
    abstract fun workoutSessionDao(): WorkoutSessionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: build(context).also { INSTANCE = it }
            }
        }

        private fun build(context: Context): AppDatabase {
            lateinit var instance: AppDatabase
            instance = Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "trainlog.db"
            )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                            instance.exerciseDao().insertAll(SeedData.baseExercises())
                        }
                    }
                })
                .build()
            return instance
        }
    }
}
