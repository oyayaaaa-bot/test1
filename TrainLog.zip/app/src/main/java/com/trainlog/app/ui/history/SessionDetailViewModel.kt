package com.trainlog.app.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.trainlog.app.data.relation.SessionWithSets
import com.trainlog.app.data.repository.WorkoutSessionRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SessionDetailViewModel(
    sessionId: Long,
    private val repository: WorkoutSessionRepository
) : ViewModel() {

    val sessionWithSets: StateFlow<SessionWithSets?> = repository.observeSessionWithSets(sessionId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun deleteSession(onDeleted: () -> Unit) {
        viewModelScope.launch {
            sessionWithSets.value?.session?.let { session ->
                repository.deleteSession(session)
                onDeleted()
            }
        }
    }
}
