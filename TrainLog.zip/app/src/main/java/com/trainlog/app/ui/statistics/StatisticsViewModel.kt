package com.trainlog.app.ui.statistics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.trainlog.app.data.entity.Exercise
import com.trainlog.app.data.repository.ExerciseRepository
import com.trainlog.app.data.repository.ExerciseStats
import com.trainlog.app.data.repository.WorkoutSessionRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

@OptIn(ExperimentalCoroutinesApi::class)
class StatisticsViewModel(
    exerciseRepository: ExerciseRepository,
    private val sessionRepository: WorkoutSessionRepository
) : ViewModel() {

    val allExercises: StateFlow<List<Exercise>> = exerciseRepository.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedExerciseId = MutableStateFlow<Long?>(null)
    val selectedExerciseId: StateFlow<Long?> = _selectedExerciseId.asStateFlow()

    val stats: StateFlow<ExerciseStats?> = _selectedExerciseId
        .flatMapLatest { id ->
            if (id == null) {
                flowOf(null)
            } else {
                sessionRepository.observeHistoryForExercise(id).map { sessionRepository.buildStats(it) }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun selectExercise(exerciseId: Long) {
        _selectedExerciseId.value = exerciseId
    }
}
