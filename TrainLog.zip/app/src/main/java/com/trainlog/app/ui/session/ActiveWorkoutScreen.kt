package com.trainlog.app.ui.session

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.trainlog.app.data.entity.WorkoutSet
import com.trainlog.app.ui.components.ExercisePickerDialog
import com.trainlog.app.ui.navigation.Screen
import com.trainlog.app.util.GenericViewModelFactory
import com.trainlog.app.util.rememberAppContainer
import kotlinx.coroutines.launch

@Composable
fun ActiveWorkoutScreen(navController: NavController, sessionId: Long) {
    val context = LocalContext.current
    val container = rememberAppContainer()
    val viewModel: ActiveWorkoutViewModel = viewModel(
        factory = GenericViewModelFactory {
            ActiveWorkoutViewModel(
                sessionId,
                container.workoutSessionRepository,
                container.workoutPlanRepository,
                container.exerciseRepository,
                context.applicationContext
            )
        }
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val restTimer by viewModel.restTimer.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var showAddExercise by remember { mutableStateOf(false) }
    var showFinishDialog by remember { mutableStateOf(false) }
    var noteTarget by remember { mutableStateOf<WorkoutSet?>(null) }

    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(uiState.session?.planName ?: "Свободная тренировка") },
                actions = {
                    TextButton(onClick = { showFinishDialog = true }) {
                        Text("Завершить")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddExercise = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Добавить упражнение")
            }
        }
    ) { padding ->
        if (uiState.isLoading) {
            Column(modifier = Modifier.fillMaxSize().padding(padding), horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(modifier = Modifier.padding(top = 32.dp))
            }
            return@Scaffold
        }

        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            restTimer?.let { timer ->
                RestTimerBanner(timer, onSkip = { viewModel.skipRestTimer() })
            }

            if (uiState.groups.isEmpty()) {
                Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                    Text("Добавьте упражнение, чтобы начать запись тренировки")
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(uiState.groups, key = { it.exercise.id }) { group ->
                        ExerciseGroupCard(
                            group = group,
                            onAddSet = {
                                val last = group.sets.lastOrNull()
                                viewModel.addSet(
                                    exerciseId = group.exercise.id,
                                    weight = last?.weight ?: group.target?.targetWeight ?: 0.0,
                                    reps = last?.reps ?: group.target?.targetReps ?: 0,
                                    isWarmup = false
                                )
                            },
                            onToggleCompleted = { set -> viewModel.toggleSetCompleted(set, group.target?.restSeconds) },
                            onValuesChanged = { set, weight, reps -> viewModel.updateSetValues(set, weight, reps) },
                            onDeleteSet = { set -> viewModel.deleteSet(set) },
                            onNoteClick = { set -> noteTarget = set }
                        )
                    }
                }
            }
        }
    }

    if (showAddExercise) {
        ExercisePickerDialog(
            exercises = uiState.allExercises,
            onDismiss = { showAddExercise = false },
            onPick = { exercise ->
                viewModel.addExerciseToWorkout(exercise.id)
                showAddExercise = false
            }
        )
    }

    noteTarget?.let { set ->
        SetNoteDialog(
            set = set,
            onDismiss = { noteTarget = null },
            onSave = { note ->
                viewModel.updateSetNote(set, note)
                noteTarget = null
            }
        )
    }

    if (showFinishDialog) {
        FinishWorkoutDialog(
            onDismiss = { showFinishDialog = false },
            onConfirm = { note ->
                scope.launch {
                    viewModel.finishWorkout(note)
                    showFinishDialog = false
                    navController.navigate(Screen.SessionDetail.createRoute(sessionId)) {
                        popUpTo(Screen.Home.route)
                    }
                }
            }
        )
    }
}

@Composable
private fun RestTimerBanner(timer: RestTimerState, onSkip: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Отдых: ${timer.remainingSeconds} с", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = onSkip) { Text("Пропустить") }
            }
            LinearProgressIndicator(
                progress = { timer.remainingSeconds.toFloat() / timer.totalSeconds.toFloat() },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
        }
    }
}

@Composable
private fun ExerciseGroupCard(
    group: ExerciseGroupUiState,
    onAddSet: () -> Unit,
    onToggleCompleted: (WorkoutSet) -> Unit,
    onValuesChanged: (WorkoutSet, Double, Int) -> Unit,
    onDeleteSet: (WorkoutSet) -> Unit,
    onNoteClick: (WorkoutSet) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(group.exercise.name, style = MaterialTheme.typography.titleMedium)
            group.target?.let { target ->
                Text(
                    "Цель: ${target.targetSets}×${target.targetReps} · ${target.targetWeight} кг",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
            Column(Modifier.padding(top = 8.dp)) {
                group.sets.forEachIndexed { index, set ->
                    SetRow(
                        index = index,
                        set = set,
                        onToggleCompleted = { onToggleCompleted(set) },
                        onValuesChanged = { weight, reps -> onValuesChanged(set, weight, reps) },
                        onDelete = { onDeleteSet(set) },
                        onNoteClick = { onNoteClick(set) }
                    )
                }
            }
            OutlinedButton(onClick = onAddSet, modifier = Modifier.padding(top = 8.dp)) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Text("Добавить подход")
            }
        }
    }
}

@Composable
private fun SetRow(
    index: Int,
    set: WorkoutSet,
    onToggleCompleted: () -> Unit,
    onValuesChanged: (weight: Double, reps: Int) -> Unit,
    onDelete: () -> Unit,
    onNoteClick: () -> Unit
) {
    var weightText by remember(set.id) { mutableStateOf(formatWeight(set.weight)) }
    var repsText by remember(set.id) { mutableStateOf(set.reps.toString()) }

    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "${index + 1}${if (set.isWarmup) " (разминка)" else ""}",
            modifier = Modifier.width(72.dp),
            style = MaterialTheme.typography.bodyMedium,
            textDecoration = if (set.isCompleted) TextDecoration.LineThrough else TextDecoration.None
        )
        OutlinedTextField(
            value = weightText,
            onValueChange = { input ->
                weightText = input.filter { it.isDigit() || it == '.' }
                weightText.toDoubleOrNull()?.let { onValuesChanged(it, repsText.toIntOrNull() ?: set.reps) }
            },
            label = { Text("кг") },
            singleLine = true,
            modifier = Modifier.width(80.dp)
        )
        OutlinedTextField(
            value = repsText,
            onValueChange = { input ->
                repsText = input.filter { it.isDigit() }
                repsText.toIntOrNull()?.let { onValuesChanged(weightText.toDoubleOrNull() ?: set.weight, it) }
            },
            label = { Text("повт.") },
            singleLine = true,
            modifier = Modifier.width(72.dp)
        )
        IconButton(onClick = onNoteClick) {
            Icon(
                Icons.Filled.Notes,
                contentDescription = "Заметка",
                tint = if (set.note.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Checkbox(checked = set.isCompleted, onCheckedChange = { onToggleCompleted() })
        IconButton(onClick = onDelete) {
            Icon(Icons.Filled.Delete, contentDescription = "Удалить подход")
        }
    }
}

private fun formatWeight(weight: Double): String =
    if (weight == weight.toLong().toDouble()) weight.toLong().toString() else weight.toString()

@Composable
private fun SetNoteDialog(set: WorkoutSet, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var note by remember { mutableStateOf(set.note) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Заметка к подходу") },
        text = {
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(note) }) { Text("Сохранить") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}

@Composable
private fun FinishWorkoutDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Завершить тренировку?") },
        text = {
            Column {
                Text("Добавьте заметку о тренировке (необязательно)")
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(note) }) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null)
                Text("Завершить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}
