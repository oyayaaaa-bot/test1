package com.trainlog.app.ui.session

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.trainlog.app.data.entity.Exercise
import com.trainlog.app.data.entity.PlanExercise
import com.trainlog.app.data.entity.WorkoutSession
import com.trainlog.app.data.entity.WorkoutSet
import com.trainlog.app.data.repository.ExerciseRepository
import com.trainlog.app.data.repository.WorkoutPlanRepository
import com.trainlog.app.data.repository.WorkoutSessionRepository
import com.trainlog.app.util.NotificationHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch

private const val DEFAULT_REST_SECONDS = 90

data class RestTimerState(val remainingSeconds: Int, val totalSeconds: Int)

data class ExerciseGroupUiState(
    val exercise: Exercise,
    val target: PlanExercise?,
    val sets: List<WorkoutSet>
)

data class ActiveWorkoutUiState(
    val isLoading: Boolean = true,
    val session: WorkoutSession? = null,
    val groups: List<ExerciseGroupUiState> = emptyList(),
    val allExercises: List<Exercise> = emptyList()
)

class ActiveWorkoutViewModel(
    private val sessionId: Long,
    private val sessionRepository: WorkoutSessionRepository,
    private val planRepository: WorkoutPlanRepository,
    private val exerciseRepository: ExerciseRepository,
    private val appContext: Context
) : ViewModel() {

    private val _pendingExerciseIds = MutableStateFlow<Set<Long>>(emptySet())
    private val _restTimer = MutableStateFlow<RestTimerState?>(null)
    val restTimer: StateFlow<RestTimerState?> = _restTimer.asStateFlow()
    private var restJob: Job? = null

    private val _uiState = MutableStateFlow(ActiveWorkoutUiState())
    val uiState: StateFlow<ActiveWorkoutUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val session = sessionRepository.getSession(sessionId)
            val dayExercisesFlow = session?.workoutDayId?.let { dayId ->
                planRepository.observeDayWithExercises(dayId)
            } ?: flowOf(null)

            combine(
                sessionRepository.observeSessionWithSets(sessionId),
                dayExercisesFlow,
                exerciseRepository.observeAll(),
                _pendingExerciseIds
            ) { sessionWithSets, dayWithExercises, allExercises, pendingIds ->
                val exercisesById = allExercises.associateBy { it.id }
                val targetsByExerciseId = dayWithExercises?.exercises
                    ?.associate { it.exercise.id to (it.exercise to it.planExercise) }
                    .orEmpty()
                val setsByExerciseId = sessionWithSets?.sets.orEmpty()
                    .groupBy { it.set.exerciseId }

                val orderedExerciseIds = linkedSetOf<Long>().apply {
                    dayWithExercises?.exercises
                        ?.sortedBy { it.planExercise.exerciseOrder }
                        ?.forEach { add(it.exercise.id) }
                    setsByExerciseId.keys.forEach { add(it) }
                    pendingIds.forEach { add(it) }
                }

                val groups = orderedExerciseIds.mapNotNull { exerciseId ->
                    val exercise = targetsByExerciseId[exerciseId]?.first ?: exercisesById[exerciseId]
                    if (exercise == null) return@mapNotNull null
                    ExerciseGroupUiState(
                        exercise = exercise,
                        target = targetsByExerciseId[exerciseId]?.second,
                        sets = setsByExerciseId[exerciseId].orEmpty().map { it.set }.sortedBy { it.setOrder }
                    )
                }

                ActiveWorkoutUiState(
                    isLoading = false,
                    session = sessionWithSets?.session ?: session,
                    groups = groups,
                    allExercises = allExercises
                )
            }.collect { state -> _uiState.value = state }
        }
    }

    fun addExerciseToWorkout(exerciseId: Long) {
        _pendingExerciseIds.value = _pendingExerciseIds.value + exerciseId
    }

    fun addSet(exerciseId: Long, weight: Double, reps: Int, isWarmup: Boolean) {
        viewModelScope.launch {
            sessionRepository.addSet(sessionId, exerciseId, weight, reps, isWarmup)
        }
    }

    fun updateSetValues(set: WorkoutSet, weight: Double, reps: Int) {
        viewModelScope.launch {
            sessionRepository.updateSet(set.copy(weight = weight, reps = reps))
        }
    }

    fun updateSetNote(set: WorkoutSet, note: String) {
        viewModelScope.launch {
            sessionRepository.updateSet(set.copy(note = note))
        }
    }

    fun toggleSetCompleted(set: WorkoutSet, restSeconds: Int?) {
        viewModelScope.launch {
            val completed = !set.isCompleted
            sessionRepository.updateSet(set.copy(isCompleted = completed))
            if (completed && !set.isWarmup) {
                startRestTimer(restSeconds ?: DEFAULT_REST_SECONDS)
            }
        }
    }

    fun deleteSet(set: WorkoutSet) {
        viewModelScope.launch { sessionRepository.deleteSet(set) }
    }

    fun startRestTimer(seconds: Int) {
        restJob?.cancel()
        if (seconds <= 0) return
        _restTimer.value = RestTimerState(seconds, seconds)
        restJob = viewModelScope.launch {
            var remaining = seconds
            while (remaining > 0) {
                delay(1000)
                remaining--
                _restTimer.value = if (remaining > 0) RestTimerState(remaining, seconds) else null
            }
            NotificationHelper.showRestFinished(appContext)
        }
    }

    fun skipRestTimer() {
        restJob?.cancel()
        _restTimer.value = null
    }

    suspend fun finishWorkout(note: String) {
        sessionRepository.finishSession(sessionId, note)
    }

    override fun onCleared() {
        restJob?.cancel()
    }
}
