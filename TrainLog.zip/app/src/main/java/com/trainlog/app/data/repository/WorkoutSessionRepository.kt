package com.trainlog.app.data.repository

import com.trainlog.app.data.dao.ExerciseHistoryPoint
import com.trainlog.app.data.dao.WorkoutSessionDao
import com.trainlog.app.data.entity.WorkoutSession
import com.trainlog.app.data.entity.WorkoutSet
import com.trainlog.app.data.relation.SessionWithSets
import kotlinx.coroutines.flow.Flow

data class ExerciseStats(
    val maxWeight: Double,
    val maxReps: Int,
    val totalVolume: Double,
    val history: List<ExerciseHistoryPoint>
)

class WorkoutSessionRepository(private val sessionDao: WorkoutSessionDao) {

    fun observeOngoingSession(): Flow<WorkoutSession?> = sessionDao.observeOngoingSession()

    fun observeRecentSessions(limit: Int = 3): Flow<List<WorkoutSession>> =
        sessionDao.observeRecentSessions(limit)

    fun observeAllFinishedSessions(): Flow<List<WorkoutSession>> = sessionDao.observeAllFinishedSessions()

    fun observeSessionWithSets(sessionId: Long): Flow<SessionWithSets?> =
        sessionDao.observeSessionWithSets(sessionId)

    fun observeSetsForSession(sessionId: Long): Flow<List<WorkoutSet>> =
        sessionDao.observeSetsForSession(sessionId)

    suspend fun getSession(sessionId: Long): WorkoutSession? = sessionDao.getSession(sessionId)

    suspend fun startSession(
        planId: Long?,
        workoutDayId: Long?,
        planName: String?,
        dayName: String?
    ): Long = sessionDao.insertSession(
        WorkoutSession(
            planId = planId,
            workoutDayId = workoutDayId,
            planName = planName,
            dayName = dayName,
            startedAt = System.currentTimeMillis(),
            finishedAt = null,
            note = ""
        )
    )

    suspend fun addSet(
        sessionId: Long,
        exerciseId: Long,
        weight: Double,
        reps: Int,
        isWarmup: Boolean
    ): Long {
        val order = sessionDao.getMaxSetOrder(sessionId, exerciseId) + 1
        return sessionDao.insertSet(
            WorkoutSet(
                sessionId = sessionId,
                exerciseId = exerciseId,
                setOrder = order,
                weight = weight,
                reps = reps,
                isWarmup = isWarmup,
                isCompleted = false,
                note = ""
            )
        )
    }

    suspend fun updateSet(set: WorkoutSet) = sessionDao.updateSet(set)

    suspend fun deleteSet(set: WorkoutSet) = sessionDao.deleteSet(set)

    suspend fun getExerciseIdsForSession(sessionId: Long): List<Long> =
        sessionDao.getExerciseIdsForSession(sessionId)

    suspend fun finishSession(sessionId: Long, note: String) {
        val session = sessionDao.getSession(sessionId) ?: return
        sessionDao.updateSession(session.copy(finishedAt = System.currentTimeMillis(), note = note.trim()))
    }

    suspend fun deleteSession(session: WorkoutSession) = sessionDao.deleteSession(session)

    fun observeHistoryForExercise(exerciseId: Long): Flow<List<ExerciseHistoryPoint>> =
        sessionDao.observeHistoryForExercise(exerciseId)

    fun buildStats(history: List<ExerciseHistoryPoint>): ExerciseStats {
        val working = history.filterNot { it.isWarmup }
        return ExerciseStats(
            maxWeight = working.maxOfOrNull { it.weight } ?: 0.0,
            maxReps = working.maxOfOrNull { it.reps } ?: 0,
            totalVolume = working.sumOf { it.weight * it.reps },
            history = history
        )
    }
}
