package com.trainlog.app.data.relation

import androidx.room.Embedded
import androidx.room.Relation
import com.trainlog.app.data.entity.Exercise
import com.trainlog.app.data.entity.PlanExercise
import com.trainlog.app.data.entity.WorkoutDay
import com.trainlog.app.data.entity.WorkoutPlan
import com.trainlog.app.data.entity.WorkoutSession
import com.trainlog.app.data.entity.WorkoutSet

data class PlanExerciseWithExercise(
    @Embedded val planExercise: PlanExercise,
    @Relation(parentColumn = "exerciseId", entityColumn = "id")
    val exercise: Exercise
)

data class DayWithExercises(
    @Embedded val day: WorkoutDay,
    @Relation(
        entity = PlanExercise::class,
        parentColumn = "id",
        entityColumn = "workoutDayId"
    )
    val exercises: List<PlanExerciseWithExercise>
)

data class PlanWithDays(
    @Embedded val plan: WorkoutPlan,
    @Relation(parentColumn = "id", entityColumn = "planId")
    val days: List<WorkoutDay>
)

data class PlanWithDaysAndExercises(
    @Embedded val plan: WorkoutPlan,
    @Relation(
        entity = WorkoutDay::class,
        parentColumn = "id",
        entityColumn = "planId"
    )
    val days: List<DayWithExercises>
)

data class WorkoutSetWithExercise(
    @Embedded val set: WorkoutSet,
    @Relation(parentColumn = "exerciseId", entityColumn = "id")
    val exercise: Exercise
)

data class SessionWithSets(
    @Embedded val session: WorkoutSession,
    @Relation(parentColumn = "id", entityColumn = "sessionId")
    val sets: List<WorkoutSetWithExercise>
)
