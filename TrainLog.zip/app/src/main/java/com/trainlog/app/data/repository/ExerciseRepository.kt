package com.trainlog.app.data.repository

import com.trainlog.app.data.dao.ExerciseDao
import com.trainlog.app.data.entity.Exercise
import kotlinx.coroutines.flow.Flow

sealed class DeleteExerciseResult {
    data object Success : DeleteExerciseResult()
    data object ErrorBaseExercise : DeleteExerciseResult()
    data object ErrorUsedInHistory : DeleteExerciseResult()
}

class ExerciseRepository(private val exerciseDao: ExerciseDao) {

    fun observeExercises(query: String, muscleGroup: String?): Flow<List<Exercise>> =
        exerciseDao.observeExercises(query.trim(), muscleGroup)

    fun observeAll(): Flow<List<Exercise>> = exerciseDao.observeAll()

    suspend fun getById(id: Long): Exercise? = exerciseDao.getById(id)

    suspend fun addCustomExercise(
        name: String,
        muscleGroup: String,
        equipment: String,
        description: String
    ): Long = exerciseDao.insert(
        Exercise(
            name = name.trim(),
            muscleGroup = muscleGroup,
            equipment = equipment.trim(),
            description = description.trim(),
            isCustom = true
        )
    )

    suspend fun updateCustomExercise(exercise: Exercise): Boolean {
        if (!exercise.isCustom) return false
        exerciseDao.update(exercise)
        return true
    }

    suspend fun deleteExercise(exercise: Exercise): DeleteExerciseResult {
        if (!exercise.isCustom) return DeleteExerciseResult.ErrorBaseExercise
        val usageCount = exerciseDao.countUsageInHistory(exercise.id)
        if (usageCount > 0) return DeleteExerciseResult.ErrorUsedInHistory
        exerciseDao.delete(exercise)
        return DeleteExerciseResult.Success
    }
}
