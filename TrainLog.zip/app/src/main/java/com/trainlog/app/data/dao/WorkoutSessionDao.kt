package com.trainlog.app.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.trainlog.app.data.entity.WorkoutSession
import com.trainlog.app.data.entity.WorkoutSet
import com.trainlog.app.data.relation.SessionWithSets
import kotlinx.coroutines.flow.Flow

data class ExerciseHistoryPoint(
    val sessionId: Long,
    val startedAt: Long,
    val weight: Double,
    val reps: Int,
    val isWarmup: Boolean
)

@Dao
interface WorkoutSessionDao {

    @Query("SELECT * FROM workout_sessions WHERE finishedAt IS NULL ORDER BY startedAt DESC LIMIT 1")
    fun observeOngoingSession(): Flow<WorkoutSession?>

    @Query("SELECT * FROM workout_sessions WHERE finishedAt IS NOT NULL ORDER BY startedAt DESC LIMIT :limit")
    fun observeRecentSessions(limit: Int): Flow<List<WorkoutSession>>

    @Query("SELECT * FROM workout_sessions WHERE finishedAt IS NOT NULL ORDER BY startedAt DESC")
    fun observeAllFinishedSessions(): Flow<List<WorkoutSession>>

    @Query("SELECT * FROM workout_sessions WHERE id = :id")
    suspend fun getSession(id: Long): WorkoutSession?

    @Transaction
    @Query("SELECT * FROM workout_sessions WHERE id = :id")
    fun observeSessionWithSets(id: Long): Flow<SessionWithSets?>

    @Insert
    suspend fun insertSession(session: WorkoutSession): Long

    @Update
    suspend fun updateSession(session: WorkoutSession)

    @Delete
    suspend fun deleteSession(session: WorkoutSession)

    @Query("SELECT * FROM workout_sets WHERE sessionId = :sessionId ORDER BY setOrder ASC")
    fun observeSetsForSession(sessionId: Long): Flow<List<WorkoutSet>>

    @Query("SELECT COALESCE(MAX(setOrder), -1) FROM workout_sets WHERE sessionId = :sessionId AND exerciseId = :exerciseId")
    suspend fun getMaxSetOrder(sessionId: Long, exerciseId: Long): Int

    @Insert
    suspend fun insertSet(set: WorkoutSet): Long

    @Update
    suspend fun updateSet(set: WorkoutSet)

    @Delete
    suspend fun deleteSet(set: WorkoutSet)

    @Query("SELECT DISTINCT exerciseId FROM workout_sets WHERE sessionId = :sessionId")
    suspend fun getExerciseIdsForSession(sessionId: Long): List<Long>

    @Query(
        """
        SELECT s.id AS sessionId, s.startedAt AS startedAt, ws.weight AS weight, ws.reps AS reps, ws.isWarmup AS isWarmup
        FROM workout_sets ws
        INNER JOIN workout_sessions s ON s.id = ws.sessionId
        WHERE ws.exerciseId = :exerciseId AND ws.isCompleted = 1 AND s.finishedAt IS NOT NULL
        ORDER BY s.startedAt ASC
        """
    )
    fun observeHistoryForExercise(exerciseId: Long): Flow<List<ExerciseHistoryPoint>>

    @Query("SELECT COUNT(*) FROM workout_sets WHERE exerciseId = :exerciseId")
    suspend fun countSetsForExercise(exerciseId: Long): Int

    @Transaction
    @Query("SELECT * FROM workout_sessions WHERE finishedAt IS NOT NULL ORDER BY startedAt ASC")
    suspend fun getAllFinishedSessionsWithSetsOnce(): List<SessionWithSets>

    @Query("SELECT * FROM workout_sessions ORDER BY id ASC")
    suspend fun getAllSessionsOnce(): List<WorkoutSession>

    @Query("SELECT * FROM workout_sets ORDER BY id ASC")
    suspend fun getAllSetsOnce(): List<WorkoutSet>
}
