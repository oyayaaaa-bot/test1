package com.trainlog.app.ui.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.trainlog.app.data.relation.WorkoutSetWithExercise
import com.trainlog.app.ui.components.ConfirmDialog
import com.trainlog.app.util.GenericViewModelFactory
import com.trainlog.app.util.rememberAppContainer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SessionDetailScreen(navController: NavController, sessionId: Long) {
    val container = rememberAppContainer()
    val viewModel: SessionDetailViewModel = viewModel(
        factory = GenericViewModelFactory {
            SessionDetailViewModel(sessionId, container.workoutSessionRepository)
        }
    )
    val sessionWithSets by viewModel.sessionWithSets.collectAsStateWithLifecycle()
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(sessionWithSets?.session?.planName ?: "Тренировка") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Удалить тренировку")
                    }
                }
            )
        }
    ) { padding ->
        val data = sessionWithSets
        if (data == null) {
            Column(modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp)) {
                Text("Тренировка не найдена")
            }
            return@Scaffold
        }

        val dateFormat = remember { SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale.getDefault()) }
        val groups = data.sets.groupBy { it.exercise.id }
            .entries
            .sortedBy { entry -> data.sets.indexOfFirst { it.exercise.id == entry.key } }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column {
                    Text(dateFormat.format(Date(data.session.startedAt)), style = MaterialTheme.typography.bodyMedium)
                    data.session.dayName?.let { Text(it, style = MaterialTheme.typography.bodyLarge) }
                    if (data.session.note.isNotBlank()) {
                        Text(
                            data.session.note,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            items(groups) { (_, sets) ->
                ExerciseSetsCard(exerciseName = sets.first().exercise.name, sets = sets)
            }
        }
    }

    if (showDeleteConfirm) {
        ConfirmDialog(
            title = "Удалить тренировку?",
            message = "Тренировка и все ее подходы будут удалены безвозвратно.",
            onConfirm = {
                viewModel.deleteSession { navController.popBackStack() }
                showDeleteConfirm = false
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }
}

@Composable
private fun ExerciseSetsCard(exerciseName: String, sets: List<WorkoutSetWithExercise>) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(exerciseName, style = MaterialTheme.typography.titleMedium)
            sets.sortedBy { it.set.setOrder }.forEachIndexed { index, item ->
                Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                    Text(
                        "${index + 1}.",
                        modifier = Modifier.padding(end = 8.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "${formatWeight(item.set.weight)} кг × ${item.set.reps}" +
                            if (item.set.isWarmup) " (разминка)" else "",
                        style = MaterialTheme.typography.bodyMedium,
                        textDecoration = if (!item.set.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                    )
                }
                if (item.set.note.isNotBlank()) {
                    Text(
                        item.set.note,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(start = 16.dp)
                    )
                }
            }
        }
    }
}

private fun formatWeight(weight: Double): String =
    if (weight == weight.toLong().toDouble()) weight.toLong().toString() else weight.toString()
