package com.trainlog.app.ui.exercises

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.trainlog.app.data.entity.Exercise
import com.trainlog.app.data.entity.MuscleGroup
import com.trainlog.app.data.repository.DeleteExerciseResult
import com.trainlog.app.data.repository.ExerciseRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class ExercisesViewModel(private val repository: ExerciseRepository) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _selectedMuscleGroup = MutableStateFlow<MuscleGroup?>(null)
    val selectedMuscleGroup: StateFlow<MuscleGroup?> = _selectedMuscleGroup.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    val exercises: StateFlow<List<Exercise>> = combine(_query, _selectedMuscleGroup) { q, mg -> q to mg }
        .flatMapLatest { (q, mg) -> repository.observeExercises(q, mg?.label) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onQueryChange(newQuery: String) {
        _query.value = newQuery
    }

    fun onMuscleGroupSelected(group: MuscleGroup?) {
        _selectedMuscleGroup.value = group
    }

    fun addExercise(name: String, muscleGroup: MuscleGroup, equipment: String, description: String) {
        if (name.isBlank()) {
            _message.value = "Введите название упражнения"
            return
        }
        viewModelScope.launch {
            repository.addCustomExercise(name, muscleGroup.label, equipment, description)
        }
    }

    fun updateExercise(exercise: Exercise, name: String, muscleGroup: MuscleGroup, equipment: String, description: String) {
        if (name.isBlank()) {
            _message.value = "Введите название упражнения"
            return
        }
        viewModelScope.launch {
            repository.updateCustomExercise(
                exercise.copy(
                    name = name.trim(),
                    muscleGroup = muscleGroup.label,
                    equipment = equipment.trim(),
                    description = description.trim()
                )
            )
        }
    }

    fun deleteExercise(exercise: Exercise) {
        viewModelScope.launch {
            when (repository.deleteExercise(exercise)) {
                DeleteExerciseResult.ErrorBaseExercise -> _message.value = "Нельзя удалить базовое упражнение"
                DeleteExerciseResult.ErrorUsedInHistory -> _message.value = "Упражнение используется в истории тренировок и не может быть удалено"
                DeleteExerciseResult.Success -> Unit
            }
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}
