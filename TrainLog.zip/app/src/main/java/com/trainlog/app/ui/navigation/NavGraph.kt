package com.trainlog.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.trainlog.app.ui.exercises.ExercisesScreen
import com.trainlog.app.ui.history.HistoryScreen
import com.trainlog.app.ui.history.SessionDetailScreen
import com.trainlog.app.ui.home.HomeScreen
import com.trainlog.app.ui.plans.PlanDetailScreen
import com.trainlog.app.ui.plans.PlansScreen
import com.trainlog.app.ui.plans.WorkoutDayScreen
import com.trainlog.app.ui.session.ActiveWorkoutScreen
import com.trainlog.app.ui.statistics.StatisticsScreen

private val topLevelRoutes = setOf(
    Screen.Home.route,
    Screen.Plans.route,
    Screen.Exercises.route,
    Screen.History.route,
    Screen.Statistics.route
)

@Composable
fun TrainLogNavGraph() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = currentRoute in topLevelRoutes

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                TrainLogBottomBar(navController, currentRoute)
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) { HomeScreen(navController) }
            composable(Screen.Exercises.route) { ExercisesScreen() }
            composable(Screen.Plans.route) { PlansScreen(navController) }
            composable(Screen.History.route) { HistoryScreen(navController) }
            composable(Screen.Statistics.route) { StatisticsScreen() }

            composable(
                route = Screen.PlanDetail.route,
                arguments = listOf(navArgument("planId") { type = NavType.LongType })
            ) { backStack ->
                val planId = backStack.arguments?.getLong("planId") ?: return@composable
                PlanDetailScreen(navController, planId)
            }

            composable(
                route = Screen.WorkoutDayEditor.route,
                arguments = listOf(navArgument("dayId") { type = NavType.LongType })
            ) { backStack ->
                val dayId = backStack.arguments?.getLong("dayId") ?: return@composable
                WorkoutDayScreen(navController, dayId)
            }

            composable(
                route = Screen.ActiveWorkout.route,
                arguments = listOf(navArgument("sessionId") { type = NavType.LongType })
            ) { backStack ->
                val sessionId = backStack.arguments?.getLong("sessionId") ?: return@composable
                ActiveWorkoutScreen(navController, sessionId)
            }

            composable(
                route = Screen.SessionDetail.route,
                arguments = listOf(navArgument("sessionId") { type = NavType.LongType })
            ) { backStack ->
                val sessionId = backStack.arguments?.getLong("sessionId") ?: return@composable
                SessionDetailScreen(navController, sessionId)
            }
        }
    }
}

@Composable
private fun TrainLogBottomBar(navController: NavHostController, currentRoute: String?) {
    NavigationBar {
        bottomNavItems.forEach { item ->
            val selected = currentRoute == item.screen.route
            NavigationBarItem(
                selected = selected,
                onClick = {
                    navController.navigate(item.screen.route) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = {
                    Icon(
                        imageVector = when (item.screen) {
                            Screen.Home -> Icons.Filled.Home
                            Screen.Plans -> Icons.Filled.ListAlt
                            Screen.Exercises -> Icons.Filled.FitnessCenter
                            Screen.History -> Icons.Filled.History
                            Screen.Statistics -> Icons.Filled.BarChart
                            else -> Icons.Filled.Home
                        },
                        contentDescription = item.label
                    )
                },
                label = { androidx.compose.material3.Text(item.label) }
            )
        }
    }
}
