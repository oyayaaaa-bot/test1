package com.trainlog.app.data.db

import com.trainlog.app.data.entity.Exercise
import com.trainlog.app.data.entity.MuscleGroup

object SeedData {

    fun baseExercises(): List<Exercise> = listOf(
        Exercise(name = "Жим штанги лежа", muscleGroup = MuscleGroup.CHEST.label, equipment = "Штанга", description = "Базовое упражнение на грудные мышцы", isCustom = false),
        Exercise(name = "Жим гантелей на наклонной скамье", muscleGroup = MuscleGroup.CHEST.label, equipment = "Гантели", description = "Акцент на верх груди", isCustom = false),
        Exercise(name = "Отжимания на брусьях", muscleGroup = MuscleGroup.CHEST.label, equipment = "Собственный вес", description = "Грудь и трицепс", isCustom = false),
        Exercise(name = "Сведение рук в кроссовере", muscleGroup = MuscleGroup.CHEST.label, equipment = "Блок", description = "Изоляция грудных мышц", isCustom = false),

        Exercise(name = "Становая тяга", muscleGroup = MuscleGroup.BACK.label, equipment = "Штанга", description = "Базовое упражнение на всю заднюю цепь", isCustom = false),
        Exercise(name = "Подтягивания", muscleGroup = MuscleGroup.BACK.label, equipment = "Собственный вес", description = "Широчайшие мышцы спины", isCustom = false),
        Exercise(name = "Тяга штанги в наклоне", muscleGroup = MuscleGroup.BACK.label, equipment = "Штанга", description = "Толщина спины", isCustom = false),
        Exercise(name = "Тяга верхнего блока", muscleGroup = MuscleGroup.BACK.label, equipment = "Блок", description = "Альтернатива подтягиваниям", isCustom = false),
        Exercise(name = "Тяга нижнего блока", muscleGroup = MuscleGroup.BACK.label, equipment = "Блок", description = "Средняя часть спины", isCustom = false),

        Exercise(name = "Приседания со штангой", muscleGroup = MuscleGroup.LEGS.label, equipment = "Штанга", description = "Базовое упражнение на ноги", isCustom = false),
        Exercise(name = "Жим ногами", muscleGroup = MuscleGroup.LEGS.label, equipment = "Тренажер", description = "Квадрицепсы и ягодицы", isCustom = false),
        Exercise(name = "Румынская тяга", muscleGroup = MuscleGroup.LEGS.label, equipment = "Штанга", description = "Бицепс бедра и ягодицы", isCustom = false),
        Exercise(name = "Выпады с гантелями", muscleGroup = MuscleGroup.LEGS.label, equipment = "Гантели", description = "Ноги и ягодицы", isCustom = false),
        Exercise(name = "Разгибание ног в тренажере", muscleGroup = MuscleGroup.LEGS.label, equipment = "Тренажер", description = "Изоляция квадрицепса", isCustom = false),
        Exercise(name = "Сгибание ног в тренажере", muscleGroup = MuscleGroup.LEGS.label, equipment = "Тренажер", description = "Изоляция бицепса бедра", isCustom = false),
        Exercise(name = "Подъем на носки стоя", muscleGroup = MuscleGroup.LEGS.label, equipment = "Тренажер", description = "Икроножные мышцы", isCustom = false),

        Exercise(name = "Жим штанги стоя", muscleGroup = MuscleGroup.SHOULDERS.label, equipment = "Штанга", description = "Базовое упражнение на плечи", isCustom = false),
        Exercise(name = "Жим гантелей сидя", muscleGroup = MuscleGroup.SHOULDERS.label, equipment = "Гантели", description = "Передняя и средняя дельта", isCustom = false),
        Exercise(name = "Махи гантелями в стороны", muscleGroup = MuscleGroup.SHOULDERS.label, equipment = "Гантели", description = "Средняя дельта", isCustom = false),
        Exercise(name = "Разведение гантелей в наклоне", muscleGroup = MuscleGroup.SHOULDERS.label, equipment = "Гантели", description = "Задняя дельта", isCustom = false),

        Exercise(name = "Подъем штанги на бицепс", muscleGroup = MuscleGroup.ARMS.label, equipment = "Штанга", description = "Бицепс", isCustom = false),
        Exercise(name = "Подъем гантелей на бицепс", muscleGroup = MuscleGroup.ARMS.label, equipment = "Гантели", description = "Бицепс", isCustom = false),
        Exercise(name = "Французский жим", muscleGroup = MuscleGroup.ARMS.label, equipment = "Штанга", description = "Трицепс", isCustom = false),
        Exercise(name = "Разгибание рук на блоке", muscleGroup = MuscleGroup.ARMS.label, equipment = "Блок", description = "Трицепс", isCustom = false),

        Exercise(name = "Скручивания", muscleGroup = MuscleGroup.CORE.label, equipment = "Собственный вес", description = "Прямая мышца живота", isCustom = false),
        Exercise(name = "Планка", muscleGroup = MuscleGroup.CORE.label, equipment = "Собственный вес", description = "Статика на все мышцы кора", isCustom = false),
        Exercise(name = "Подъем ног в висе", muscleGroup = MuscleGroup.CORE.label, equipment = "Турник", description = "Нижний пресс", isCustom = false),

        Exercise(name = "Бег", muscleGroup = MuscleGroup.CARDIO.label, equipment = "Беговая дорожка", description = "Кардионагрузка", isCustom = false),
        Exercise(name = "Гребной тренажер", muscleGroup = MuscleGroup.CARDIO.label, equipment = "Тренажер", description = "Кардио на все тело", isCustom = false),

        Exercise(name = "Берпи", muscleGroup = MuscleGroup.FULL_BODY.label, equipment = "Собственный вес", description = "Комплексное упражнение на все тело", isCustom = false),
        Exercise(name = "Рывок гири", muscleGroup = MuscleGroup.FULL_BODY.label, equipment = "Гиря", description = "Взрывная сила и выносливость", isCustom = false)
    )
}
