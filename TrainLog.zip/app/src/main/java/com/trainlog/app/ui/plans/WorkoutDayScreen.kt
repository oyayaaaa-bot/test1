package com.trainlog.app.ui.plans

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.trainlog.app.data.entity.Exercise
import com.trainlog.app.data.entity.PlanExercise
import com.trainlog.app.data.relation.PlanExerciseWithExercise
import com.trainlog.app.ui.components.ConfirmDialog
import com.trainlog.app.ui.components.ExercisePickerDialog
import com.trainlog.app.ui.components.NumberField
import com.trainlog.app.util.GenericViewModelFactory
import com.trainlog.app.util.rememberAppContainer

@Composable
fun WorkoutDayScreen(navController: NavController, dayId: Long) {
    val container = rememberAppContainer()
    val viewModel: WorkoutDayViewModel = viewModel(
        factory = GenericViewModelFactory {
            WorkoutDayViewModel(dayId, container.workoutPlanRepository, container.exerciseRepository)
        }
    )
    val dayWithExercises by viewModel.dayWithExercises.collectAsStateWithLifecycle()
    val allExercises by viewModel.allExercises.collectAsStateWithLifecycle()

    var showPicker by remember { mutableStateOf(false) }
    var pickedExercise by remember { mutableStateOf<Exercise?>(null) }
    var editingItem by remember { mutableStateOf<PlanExerciseWithExercise?>(null) }
    var deletingItem by remember { mutableStateOf<PlanExerciseWithExercise?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(dayWithExercises?.day?.name ?: "День программы") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showPicker = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Добавить упражнение")
            }
        }
    ) { padding ->
        val exercises = dayWithExercises?.exercises.orEmpty().sortedBy { it.planExercise.exerciseOrder }

        if (exercises.isEmpty()) {
            Column(modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp)) {
                Text("В этом дне пока нет упражнений. Добавьте первое с помощью кнопки ниже.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(exercises, key = { it.planExercise.id }) { item ->
                    PlanExerciseRow(
                        item = item,
                        canMoveUp = exercises.indexOf(item) > 0,
                        canMoveDown = exercises.indexOf(item) < exercises.size - 1,
                        onEdit = { editingItem = item },
                        onDelete = { deletingItem = item },
                        onMoveUp = { viewModel.moveExercise(item, exercises, -1) },
                        onMoveDown = { viewModel.moveExercise(item, exercises, 1) }
                    )
                }
            }
        }
    }

    if (showPicker) {
        ExercisePickerDialog(
            exercises = allExercises,
            onDismiss = { showPicker = false },
            onPick = { exercise ->
                pickedExercise = exercise
                showPicker = false
            }
        )
    }

    pickedExercise?.let { exercise ->
        PlanExerciseFormDialog(
            title = "Добавить: ${exercise.name}",
            initial = null,
            onDismiss = { pickedExercise = null },
            onSave = { sets, reps, weight, rest, note ->
                viewModel.addExercise(exercise.id, sets, reps, weight, rest, note)
                pickedExercise = null
            }
        )
    }

    editingItem?.let { item ->
        PlanExerciseFormDialog(
            title = item.exercise.name,
            initial = item.planExercise,
            onDismiss = { editingItem = null },
            onSave = { sets, reps, weight, rest, note ->
                viewModel.updateExercise(
                    item.planExercise.copy(
                        targetSets = sets,
                        targetReps = reps,
                        targetWeight = weight,
                        restSeconds = rest,
                        note = note
                    )
                )
                editingItem = null
            }
        )
    }

    deletingItem?.let { item ->
        ConfirmDialog(
            title = "Удалить упражнение из дня?",
            message = "«${item.exercise.name}» будет удалено из этого дня программы.",
            onConfirm = {
                viewModel.deleteExercise(item.planExercise)
                deletingItem = null
            },
            onDismiss = { deletingItem = null }
        )
    }
}

@Composable
private fun PlanExerciseRow(
    item: PlanExerciseWithExercise,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.exercise.name, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "${item.planExercise.targetSets}×${item.planExercise.targetReps} · ${item.planExercise.targetWeight} кг · отдых ${item.planExercise.restSeconds} с",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    if (item.planExercise.note.isNotBlank()) {
                        Text(item.planExercise.note, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                IconButton(onClick = onMoveUp, enabled = canMoveUp) {
                    Icon(Icons.Filled.ArrowUpward, contentDescription = "Вверх")
                }
                IconButton(onClick = onMoveDown, enabled = canMoveDown) {
                    Icon(Icons.Filled.ArrowDownward, contentDescription = "Вниз")
                }
                IconButton(onClick = onEdit) {
                    Icon(Icons.Filled.Edit, contentDescription = "Изменить")
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Удалить")
                }
            }
        }
    }
}

@Composable
private fun PlanExerciseFormDialog(
    title: String,
    initial: PlanExercise?,
    onDismiss: () -> Unit,
    onSave: (sets: Int, reps: Int, weight: Double, rest: Int, note: String) -> Unit
) {
    var sets by remember { mutableStateOf((initial?.targetSets ?: 3).toString()) }
    var reps by remember { mutableStateOf((initial?.targetReps ?: 10).toString()) }
    var weight by remember { mutableStateOf((initial?.targetWeight ?: 0.0).toString()) }
    var rest by remember { mutableStateOf((initial?.restSeconds ?: 60).toString()) }
    var note by remember { mutableStateOf(initial?.note.orEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField("Подходы", sets, { sets = it }, modifier = Modifier.weight(1f))
                    NumberField("Повторы", reps, { reps = it }, modifier = Modifier.weight(1f))
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    NumberField("Вес, кг", weight, { weight = it }, modifier = Modifier.weight(1f), allowDecimal = true)
                    NumberField("Отдых, с", rest, { rest = it }, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Заметка") },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    sets.toIntOrNull() ?: 0,
                    reps.toIntOrNull() ?: 0,
                    weight.toDoubleOrNull() ?: 0.0,
                    rest.toIntOrNull() ?: 0,
                    note
                )
            }) { Text("Сохранить") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}
